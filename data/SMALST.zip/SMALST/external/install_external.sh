git clone https://github.com/shubhtuls/PerceptualSimilarity

git clone https://github.com/hiroharu-kato/neural_renderer --branch v1.1.0
cd neural_renderer
python setup.py install
